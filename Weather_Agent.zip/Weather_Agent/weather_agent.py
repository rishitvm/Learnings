import os
import requests
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain.tools import tool
from langchain.agents import AgentType, initialize_agent
from fastapi import FastAPI
from pydantic import BaseModel

# Load environment variables
load_dotenv()

# Get API keys
GROQ_API = os.getenv("GROQ_API_KEY")
WEATHER_API = os.getenv("WEATHER_API_KEY")

# Initialize LLM from Groq
llm = ChatOpenAI(
    openai_api_base="https://api.groq.com/openai/v1",
    openai_api_key=GROQ_API,
    model_name="gemma2-9b-it",
    temperature=0.5
)

# Weather tool definition with docstring
@tool
def get_weather(city: str) -> str:
    """Get the current weather for a given city using OpenWeatherMap API."""
    url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={WEATHER_API}&units=metric"
    try:
        response = requests.get(url)
        data = response.json()
        if response.status_code != 200 or "main" not in data:
            return f"Couldn't fetch weather for '{city}'."
        temp = data["main"]["temp"]
        weather = data["weather"][0]["description"]
        return f"The weather in {city} is {weather} with a temperature of {temp}°C."
    except Exception as e:
        return f"Error: {str(e)}"

# Register tool
tools = [get_weather]

# Initialize agent
agent = initialize_agent(
    tools=tools,
    llm=llm,
    agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION,
    verbose=True
)

# FastAPI app
app = FastAPI()

# Input schema
class Query(BaseModel):
    question: str

# API endpoint
@app.post("/ask_agent")
def ask_agent(query: Query):
    try:
        response = agent.run(query.question)
        return {"response": response}
    except Exception as e:
        return {"error": str(e)}
    