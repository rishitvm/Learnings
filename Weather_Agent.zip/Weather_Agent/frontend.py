import streamlit as st
import requests

st.title("🌦️ Weather Agent")

city = st.text_input("Enter a city to get the weather")

if st.button("Ask Agent"):
    if city:
        with st.spinner("Talking to the Agent..."):
            try:
                response = requests.post(
                    "http://127.0.0.1:8000/ask_agent",
                    json={"question": city}
                )
                result = response.json()
                if "response" in result:
                    st.success(result["response"])
                else:
                    st.error(f"Agent Error: {result.get('error', 'Unknown error')}")
            except Exception as e:
                st.error(f"Request failed: {str(e)}")
    else:
        st.warning("Please enter a city.")
