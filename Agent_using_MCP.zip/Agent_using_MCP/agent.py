import asyncio
import os
import sys
from dotenv import load_dotenv
from langchain_groq import ChatGroq
from mcp_use import MCPAgent, MCPClient

load_dotenv()
GROQ_API_KEY = os.getenv("GROQ_API_KEY")

async def run_memory_chat():
    config_file = "mcp_tool_servers.json"
    print("Initialising Chat...")
    client = MCPClient.from_config_file(config_file)
    llm = ChatGroq(model = "qwen-qwq-32b", api_key = GROQ_API_KEY)
    agent = MCPAgent(
        llm = llm,
        client = client,
        max_steps = 15,
        memory_enabled = True,
    )
    print("Hi! I am your AI Assistant")
    try:
        while True:
            user_input = input("User: ")
            if user_input.lower() == "exit":
                break
            if user_input.lower() == "clear":
                agent.clear_conversation_history()
                print("History Cleared")
            else:
                print("Assistant: ")
                try:
                    response = await agent.run(user_input)
                    print(response)
                except Exception as e:
                    print(f"Error: {str(e)}")
    except Exception as e:
        print(f"Error: {str(e)}")
    finally:
        if client and client.sessions:
            await client.close_all_sessions()

if __name__ == "__main__":
    asyncio.run(run_memory_chat())