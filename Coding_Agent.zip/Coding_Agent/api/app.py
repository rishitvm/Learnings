import streamlit as st
import requests
import os
from dotenv import load_dotenv

load_dotenv()

# Define backend endpoints
#FASTAPI_BACKEND = "http://127.0.0.1:8000"

FASTAPI_BACKEND = os.getenv("FASTAPI_BACKEND")

st.title("Code Generator & Runner")

# Ask for DSA question
question = st.text_area("Enter your DSA question")

if st.button("Generate Code"):
    response = requests.post(f"{FASTAPI_BACKEND}/generate", json = {"question": question})
    if response.status_code == 200:
        data = response.json()
        st.success("✅ Code Generated and Saved!")
        st.code(data["code"], language="python")

        # Save filename and detect inputs from code
        st.session_state["code"] = data["code"]
        st.session_state["file_path"] = data["file_path"]

        # Detect number of `input()` calls
        input_count = data["code"].count("input(")
        st.session_state["input_count"] = input_count
    else:
        st.error("Error from server: " + response.text)

# Show inputs if code was generated
if "input_count" in st.session_state:
    st.subheader("Provide inputs:")
    user_inputs = []

    for i in range(st.session_state["input_count"]):
        user_input = st.text_input(f"Input {i+1}", key=f"input_{i}")
        user_inputs.append(user_input)

    if st.button("Run Code"):
        payload = {
            "inputs": user_inputs,
            "file_path": st.session_state["file_path"]
        }
        run_response = requests.post(f"{FASTAPI_BACKEND}/execute", json = payload)
        if run_response.status_code == 200:
            output_data = run_response.json()
            st.text_area("💡 Output", output_data["stdout"])
            if output_data["stderr"]:
                st.text_area("⚠️ Errors", output_data["stderr"])
        else:
            st.error("Error running the code.")
