from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import subprocess
import os

from langchain_groq import ChatGroq
from langchain.agents import initialize_agent, AgentType
from langchain.tools import tool
from dotenv import load_dotenv

# Load .env keys
load_dotenv()
GROQ_API_KEY = os.getenv("GROQ_API_KEY")

# Initialize LLM
llm = ChatGroq(model="llama-3.1-8b-instant", api_key=GROQ_API_KEY)

@tool
def code(question: str) -> str:
    """Generates Python code from a DSA question using the LLM."""
    prompt = f"""
    Hi Llama! Generate Python code to solve: {question}
    Use input() for user inputs.
    Only return raw python code with no explanation or markdown.
    """
    return llm.invoke(prompt)

tools = [code]

agent = initialize_agent(
    llm=llm,
    tools=tools,
    agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION,
    verbose=True
)

# 🔧 This function is used in the FastAPI route below
def generate_and_save_code(question: str):
    response = llm.invoke(question).content
    code_part = response.split("```python", 1)[-1].split("```")[0].lstrip()
    with open("generated.py", "w", encoding="utf-8") as f:
        f.write(code_part)
    return {
        "code": code_part,
        "file_path": "generated.py"
    }

# ✅ FastAPI App and Routes
app = FastAPI()

origins = ["*"]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_methods=["*"], allow_headers=["*"])

class QuestionRequest(BaseModel):
    question: str

class ExecutionRequest(BaseModel):
    inputs: list[str]

@app.post("/generate")
def generate_code(request: QuestionRequest):
    code = generate_and_save_code(request.question)
    return code

@app.post("/execute")
def execute_code(request: ExecutionRequest):
    input_text = "\n".join(request.inputs)
    result = subprocess.run(
        ["python", "generated.py"],
        input=input_text,
        text=True,
        capture_output=True
    )
    return {
        "stdout": result.stdout,
        "stderr": result.stderr
    }
