# Get the first integer from the user
num1 = int(input("Enter the first integer: "))

# Get the second integer from the user
num2 = int(input("Enter the second integer: "))

# Add the two numbers
result = num1 + num2

# Print the result
print("The sum of the two numbers is: ", result)
