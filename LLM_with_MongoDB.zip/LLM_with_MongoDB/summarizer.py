from dotenv import load_dotenv
from langchain_groq import ChatGroq
import json
import os
from pymongo import MongoClient

load_dotenv()

GROQ_API_KEY = os.getenv("GROQ_API_KEY")

client = MongoClient("mongodb://localhost:27017/")
db = client["ai"]
collection = db["patient_data"]

llm = ChatGroq(model = "llama-3.1-8b-instant", api_key = GROQ_API_KEY)

def generate_summary(case):
    prompt = f"""
                You are a good Medical AI Assistant. This is the medical report of a user with age 
                {case.get("age")}, the symptoms faced by the user are {case.get("symptoms")} and the 
                diagnosis given is {case.get("diagnosis")}. As an AI medical assistant your task is 
                to summarize about the case and prescribe only medicine names without any 
                instructions. I don't need any headings or notes apart from these two. Just give the entire
                result in a line like Summary: Medicines:
            """
    response = llm.invoke(prompt)
    return response.content.strip()

def process_cases():
    cases = collection.find({})
    for i,case in enumerate(cases):
        result = generate_summary(case)
        summary = result.split("Summary: ")[-1].split("Medicines: ")[0].strip()
        prescription = result.split("Summary: ")[-1].split("Medicines: ")[1].strip()
        collection.update_one({"_id":case["_id"]},{"$set":{"summary":summary, "prescription":prescription}})
        print(f"Summary and Prescription added for patient {i+1}")

if __name__ == "__main__":
    process_cases()