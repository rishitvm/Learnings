from pymongo import MongoClient
import json

client = MongoClient("mongodb://localhost:27017/")
db = client["ai"]
collection = db["patient_data"]

with open("data.json", "r") as f:
    data = json.load(f)

collection.insert_many(data)
print("Data written on Database")