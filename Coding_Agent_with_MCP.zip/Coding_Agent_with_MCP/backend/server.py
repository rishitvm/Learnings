from mcp.server.fastmcp import FastMCP
from langchain_groq import ChatGroq
import os
import subprocess
from dotenv import load_dotenv
import json

load_dotenv()
GROQ_API_KEY = os.getenv("GROQ_API_KEY")

# Create MCP instance
mcp = FastMCP("CodingServer")

# Connect to Groq LLM
llm = ChatGroq(
    model="llama-3.1-8b-instant",
    api_key=GROQ_API_KEY
)

# Tool to generate code
@mcp.tool()
def generate_code(question: str) -> str:
    """Generate code from a DSA question."""
    prompt = f"""
    Hi Llama! Write Python code to solve: {question}
    Use input() for inputs.
    Output only code — no markdown or explanation.
    """
    response = llm.invoke(prompt).content
    # Strip markdown if present
    if "```python" in response:
        code = response.split("```python", 1)[-1].split("```")[0].strip()
    else:
        code = response.strip()

    with open("generated.py", "w", encoding="utf-8") as f:
        f.write(code)
    return code

@mcp.tool()
def run_code(input_data: list[str]) -> dict:
    input_text = "\n".join(input_data)
    result = subprocess.run(
        ["python", "generated.py"],
        input=input_text,
        text=True,
        capture_output=True,
        timeout=10
    )
    return {
        "stdout": result.stdout,
        "stderr": result.stderr
    }

if __name__ == "__main__":
    mcp.run(transport = "streamable-http")
