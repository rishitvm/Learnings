from fastapi import FastAPI
from pydantic import BaseModel
from langchain_mcp_adapters.client import MultiServerMCPClient
import asyncio
import json

app = FastAPI()

class CodeRequest(BaseModel):
    question: str

class RunRequest(BaseModel):
    input_data: list[str]

client = MultiServerMCPClient({
    "CodingServer": {
        "url": "http://localhost:8000/mcp",
        "transport": "streamable_http",
    }
})
tools = {}

@app.on_event("startup")
async def startup_event():
    global tools
    tools_list = await client.get_tools()
    tools = {tool.name: tool for tool in tools_list}

@app.post("/generate")
async def generate_code(request: CodeRequest):
    response = await tools["generate_code"].ainvoke({"question": request.question})
    return {
        "code": response,
        "file_path": "generated.py"
    }

@app.post("/run")
async def run_code(request: RunRequest):
    response = await tools["run_code"].ainvoke({"input_data": request.input_data})
    if isinstance(response, str):
        response = json.loads(response)
    return {
        "stdout": response["stdout"],
        "stderr": response["stderr"]
    }

