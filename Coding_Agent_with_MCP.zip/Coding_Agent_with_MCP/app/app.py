import streamlit as st
import requests

FASTAPI_URL = "http://backend:9000"  # Your FastAPI backend

st.title("Coding Agent")

# Step 1: Input question
question = st.text_input("Enter a DSA question:")
if st.button("Generate Code") and question.strip():
    with st.spinner("Generating code..."):
        res = requests.post(f"{FASTAPI_URL}/generate", json={"question": question})
        if res.status_code == 200:
            code = res.json()["code"]
            st.session_state.generated_code = code
            st.session_state.file_path = res.json()["file_path"]
            st.code(code, language="python")
        else:
            st.error("Failed to generate code.")

# Step 2: Input fields from code
if "generated_code" in st.session_state:
    code = st.session_state.generated_code
    num_inputs = code.count("input(")
    st.subheader("Enter Inputs:")
    user_inputs = []

    for i in range(num_inputs):
        inp = st.text_input(f"Input {i+1}")
        user_inputs.append(inp)

    # Step 3: Run code
    if st.button("Run Code"):
        with st.spinner("Running..."):
            res = requests.post(f"{FASTAPI_URL}/run", json={"input_data": user_inputs})
            if res.status_code == 200:
                output = res.json()
                st.subheader("Output")
                st.text(output["stdout"])
                if output["stderr"]:
                    st.error(output["stderr"])
            else:
                st.error("Error running code.")
