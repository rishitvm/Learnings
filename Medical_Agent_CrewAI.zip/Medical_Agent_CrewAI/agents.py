# agents.py
from crewai import Agent, LLM
from tools import tool1, tool2
import os
from dotenv import load_dotenv

load_dotenv()

GROQ_API_KEY = os.getenv("GROQ_API_KEY")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")


medical_agent = Agent(
    role="Extract the information from the medical document",
    goal="Use the medical document and identify the medical disease or symptoms",
    llm=LLM(
        provider = "groq",
        model="llama-3.1-8b-instant",
        api_key=GROQ_API_KEY
    ),
    verbose=True,
    memory=True,
    backstory=(
        "You are a very good AI Medical Assistant who analyses the lab reports and identifies the disease and symptoms"
    ),
    allow_delegation=True,
    tools=[tool1]
)

recommender = Agent(
    role="Use the information and analyze the websites to get the medicine name.",
    goal="Use the extracted medical information and get the suitable medicine name",
    llm=LLM(
        provider = "groq",
        model="llama-3.1-8b-instant",
        api_key=GROQ_API_KEY
    ),
    verbose=True,
    memory=True,
    backstory=(
        "You are a very good AI Medical Assistant who uses the lab report information and identifies the correct medicine"
    ),
    allow_delegation=False,
    tools=[tool2]
)
