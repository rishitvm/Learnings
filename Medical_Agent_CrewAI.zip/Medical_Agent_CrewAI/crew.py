from crewai import Crew, Process
from agents import recommender, medical_agent
from tasks import task1, task2

crew = Crew(
    agents = [medical_agent, recommender],
    tasks = [task1, task2],
    process=Process.sequential,
    memory=True,
    cache=True,
    max_rpm=100,
    share_crew=True
)

result = crew.kickoff(inputs={'topic': 'Analyze the medical document given'})
print(result)
