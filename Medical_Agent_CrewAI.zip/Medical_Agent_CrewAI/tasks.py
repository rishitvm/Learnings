from crewai import Task
from agents import medical_agent, recommender
from tools import tool1, tool2

task1 = Task(
    description="Identify the disease and symptoms from the PDF medical document.",
    expected_output="Output the disease and symptoms only",
    tools=[tool1],
    agent=medical_agent,
)

task2 = Task(
    description="Use the disease and symptoms identified to search for the correct medicines.",
    expected_output="Output the medicine names only",
    tools=[tool2],
    agent=recommender,
)
