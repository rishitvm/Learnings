import os
from dotenv import load_dotenv
from crewai_tools import PDFSearchTool, WebsiteSearchTool

load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
GROQ_API_KEY = os.getenv("GROQ_API_KEY")

tool1 = PDFSearchTool(pdf = "doc.pdf")

tool2 = WebsiteSearchTool(website = "https://www.mayoclinic.org/")